<nav id="sidebarIzq">
	<h3>Navegación</h3>
	<ul>
		<li><a href="<?= RUTA_APP?>/index.php">Inicio</a></li>
		<li><a href="<?= RUTA_APP?>/contenido.php">Ver contenido</a></li>
		<li><a href="<?= RUTA_APP?>/admin.php">Administrar</a></li>
		<li><a href="<?= RUTA_APP?>/tablon.php">Tablon</a></li>
	</ul>
</nav>