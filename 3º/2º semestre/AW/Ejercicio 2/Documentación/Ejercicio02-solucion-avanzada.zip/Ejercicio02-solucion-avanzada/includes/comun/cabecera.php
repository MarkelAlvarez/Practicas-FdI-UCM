<?php

require_once __DIR__.'/../usuarios.php';

?>
<header>
	<h1>Mi gran página web</h1>
	<div class="saludo">
	  <?= saludo() ?>
	</div>
</header>

