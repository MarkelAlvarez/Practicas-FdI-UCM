<footer>
	Pie de página
</footer>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
<script src="<?= RUTA_APP?>/js/app.js" crossorigin="anonymous"></script>